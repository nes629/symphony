let speed = 0.05;  // Speed of the oscillation
let amplitude = 20;  // Height of the oscillation
let baseY = 250;  // Base Y position for emojis

function setup() {
  createCanvas(400, 400);
  textSize(75);
}

function draw() {
  background(220);

  // Calculate y positions for each emoji
  let yDolphin = baseY + sin(frameCount * speed) * amplitude;
  let yWhale = baseY + sin((frameCount * speed) + PI) * amplitude; // Offset to make it alternate

  // Draw the emojis at their calculated y positions
  text("🐬", 100, yDolphin); // Dolphin emoji
  text("🐳", 300, yWhale);   // Whale emoji
}
