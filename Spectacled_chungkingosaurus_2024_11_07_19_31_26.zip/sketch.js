

let symphony;
let waveheight = 275
let waveMaxHeight = 125;
let baseT = 0;

let angle = 0; // Angle in radians, starting at 0
let radius = 150; // Radius of the circular path
let centerX = 300; // X position of the center of the circle
let centerY = 200; // Y position of the center of the circle

let redVal = 0;
let greenVal = 0;
//youtube tutorial of how to play bg music
// the loads the sounds before its neede to play
//function preload(){
  // this makes it so that I dont have to classify as .mp3, this is used more when theres multiple mp3 files, so theres no repetitive typing.
  //soundFormats("mp3");
  // classifies symphony
  //symphony = loadSound("music/symphony");
//}

function setup() {
  createCanvas(600, 400);
  colorMode(HSB);
  noStroke();
  background("lightblue");
  
  backgroundMusic();
}


//youtube tutorial of how to play bg music
// we made this function to play audio in the background
function backgroundMusic(){
  userStartAudio();
}

function draw() {
  //ocean and sun
  
  
  // learned from wave motion on p5js library
  drawWaves(2);
  
}

function drawWaves(number) {
  // loop for all of our rows and draw each wave
  // loop backwards, top layer to bottom layer, to draw them one on top of the other
  // nicely
  for (let i = number; i >= 0; i--) {
    drawWave(i, number);
  }
  // increase the base time parameter so that the waves move
  baseT += 0.006;
}


function drawWave(n, rows) {
  // calculate the base y for this wave based on an offset from the
  // bottom of the canvas and subtracting the number of waves
  // to move up. were dividing the wave height in order to make the
  // waves overlap
  let baseY = height - n*waveMaxHeight/3;
  // get the starting time parameter for this wave based on the
  // base time and an offset based on the wave number
  let t = baseT + n*100;
  // well start each wave at 0 on the x axis
  let startX = 0;
  // lets start drawing
  push();
  // well use the HSB model to vary their color more easily
  // calculate the hue (0 - 360) based on the wave number, mapping
  // it to an HSB hue value
  let hue = map(n, 0, 2, 225, 200);
  fill(hue, 160, 75);
  noStroke();
  // were using vertex-based drawing
  beginShape();
  // starting vertex!
  vertex(startX, baseY);
  // loop along the x axis drawing vertices for each point
  // along the noise() function in increments of 10
  for (let x = startX; x <= width; x += 10) {
    // calculate the wave's y based on the noise() function
    // and the baseY
    let y = baseY - map(noise(t), 0, 1, 0, waveMaxHeight);
    // draw our vertex
    vertex(x, y);
    // increase our time parameter so the wave varies on y
    t += 0.01;
  }
  // draw the final three vertices to close the shape around
  // the edges of the canvas
  vertex(width, baseY);
  vertex(width, height);
  vertex(0, height);
  // Done!
  endShape();
}


// p5js keyPressed explanation/tutorial
function keyPressed(){
  if (keyCode === LEFT_ARROW) {
    // p5js tutorials Color Interpolation
    // Top color
    let colorA = color(210, 80, 85);

    // Bottom color
    let colorB = color(29, 70, 70);

    // Number of stripes
    let stripeCount = 100;

    // Divide height of canvas by number of stripes
    let stripeHeight = height / stripeCount;

    // Starts at the top of the canvas,
    // repeats until its at the bottom
    // move down by stripeHeight each time,
    for (let y = 0; y < height; y += stripeHeight) {
      // Convert y position to number between
      // 0 (top of canvas) and 1 (bottom of canvas)
      let fadeAmount = y / height;

      // blend colors/fill in middle colors
      let betweenColor = lerpColor(colorA, colorB, fadeAmount);

      // Draw the stripes
      fill(betweenColor);
      rect(0, y, width, stripeHeight);
    }
    textSize(75)
    text("🐬", mouseX, mouseY);
    
    //youtube tutorial of how to play bg music
    // plays symphony
    symphony.play();
    // dosent loop the audio
    symphony.loop(false);
    // sets the volume
    symphony.setVolume(0.3);
    // plays the audio
    userStartAudio();
    
  }
  
  // p5js tutorials
  if (keyCode === RIGHT_ARROW){
      background("lightblue");
  }
  
  
}


