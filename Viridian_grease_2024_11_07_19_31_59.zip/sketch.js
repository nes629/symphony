let angle = 0; // Angle in radians, starting at 0
let radius = 150; // Radius of the circular path
let centerX = 300; // X position of the center of the circle
let centerY = 200; // Y position of the center of the circle

let redVal = 0;
let greenVal = 0;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(redVal, greenVal, 0);

  // Calculate the sun's position based on the angle for circular motion
  let sunX = centerX + radius * cos(angle);
  let sunY = centerY + radius * sin(angle);

  // Draw the sun with two overlapping circles for effect
  stroke(235, 229, 52);
  fill(255, 135, 5, 60);
  circle(sunX, sunY, 100);
  fill(255, 100, 0, 100);
  circle(sunX, sunY, 80);

  // Increment the angle to move the sun along the circular path
  angle += 0.02; // Adjust this value to change the speed of rotation

  // Update the background color as the sun moves
  redVal = map(sin(angle), -1, 1, 100, 100);
  greenVal = map(cos(angle), -1, 1, 0, 180);

  // Reset background to black if mouse is pressed and sun is at starting point
  if (mouseIsPressed && angle % TWO_PI < 0.02) { 
    background(0);
  }
}